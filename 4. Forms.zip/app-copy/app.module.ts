import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { MediaItemComponent } from './media-item.component';
import { MediaItemListComponent } from './media-item-list.component';
import { FavoriteDirective } from './favorite.directive';
import { CategoryListPipe } from './category-list.pipe';
import { MediaItemFormComponent } from './media-item-form.component';

/* Decorator is a piece of code will be applied to class, or field or method coming before */
@NgModule({
  /* Metadata properties used as an array
  Imports bring in other Angular modules that module may need
  Declarations used to make components, directives, and pipes available to your module
  Bootstrap used for root module; tells Angular which components are Bootstrap entry point */
  imports: [
    BrowserModule // browser-based app has core directives and pipes to work with DOM
    ReactiveFormsModule
  ],
  declarations: [
    AppComponent,
    MediaItemComponent,
    MediaItemListComponent,
    FavoriteDirective,
    CategoryListPipe,
    MediaItemFormComponent
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule {}
