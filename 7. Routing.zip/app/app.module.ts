import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HttpXhrBackend } from '@angular/common/http';
import { AppComponent } from './app.component';
import { MediaItemComponent } from './media-item.component';
import { MediaItemListComponent } from './media-item-list.component';
import { FavoriteDirective } from './favorite.directive';
import { CategoryListPipe } from './category-list.pipe';
import { lookupListToken, lookupLists } from './providers';
import { MockXHRBackend } from './mock-xhr-backend';
import { routing } from './app.routing';
import { NewItemModule } from './new-item/new-item.module';

/* Decorator is a piece of code will be applied to class, or field or method coming before
This is our ROOT/TOP decorator */
@NgModule({
  /* Metadata properties used as an array
  Imports bring in other Angular modules that module may need
  Declarations used to make components, directives, and pipes available to your module
  Bootstrap used for root module; tells Angular which components are Bootstrap entry point */
  imports: [
    BrowserModule, // browser-based app has core directives and pipes to work with DOM
    HttpClientModule, // NG module includes services and types to perform HTTP work
    routing,
    /* NewItemModule Angular will not include this in the app module,
    rather a separate bundle delivered when a route is requested for it */
  ],
  declarations: [
    AppComponent,
    MediaItemComponent,
    MediaItemListComponent,
    FavoriteDirective,
    CategoryListPipe
  ],
  providers: [
    { provide: lookupListToken, useValue: lookupLists },
    { provide: HttpXhrBackend, useClass: MockXHRBackend }
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule {}
