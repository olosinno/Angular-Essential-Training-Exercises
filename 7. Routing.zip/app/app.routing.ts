import { Routes, RouterModule } from '@angular/router';
import { MediaItemListComponent } from './media-item-list.component';

/* No need to export this as we won't be using it outside of this file
Route object is expected to have a path property */
const appRoutes: Routes = [
  {
    /* For value of loadChildren property, we use a function that makes use of
    dynamic import statement to load module only when requested */
    path: 'add',
    loadChildren: () => import('./new-item/new-item.module').then(m => m.NewItemModule)
  },
  { path: ':medium', component: MediaItemListComponent },
  { path: '', pathMatch: 'full', redirectTo: 'all' }
];

export const routing = RouterModule.forRoot(appRoutes);
