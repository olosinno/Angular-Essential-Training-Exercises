import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

/* Decorator receives object literal with property name provided in,
and sets that to a String literal with value of root */
@Injectable({
  providedIn: 'root'
})
/* Enables refactoring of get method to call this.http.get */
export class MediaItemService {
  constructor(private http: HttpClient) {}

  get(medium: string) {
    const getOptions = {
      params: { medium }
    };
    return this.http.get<MediaItemsResponse>('mediaitems', getOptions)
      .pipe(
        map((response: MediaItemsResponse) => {
          return response.mediaItems;
        }),
        catchError(this.handleError)
      );
  }

  /* Delivers both header and body parameters, header as string and body as application/JSON */
  add(mediaItem: MediaItem) {
    return this.http.post('mediaitems', mediaItem);
    .pipe(catchError(this.handleError));
  }

  /* Tell String interpolation how to put our variable in String build with $ */
  delete(mediaItem: MediaItem) {
    return this.http.delete(`mediaitems/${mediaItem.id}`);
  }
}

private handleError(error: HttpErrorResponse) {
  console.log(error.message);
  return throwError('A data error occurred, please try again.');
}

interface MediaItemsResponse {
  mediaItems: MediaItem[];
}

export interface MediaItem {
  id: number;
  name: string;
  medium: string;
  category: string;
  year: number;
  watchedOn: number;
  isFavorite: boolean;
}
