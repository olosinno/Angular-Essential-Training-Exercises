import { Directive, HostBinding, HostListener, Input } from '@angular/core';

/* Selector name prefix mw stands for media watcher, kept unique for this program */
@Directive({
  selector: '[mwFavorite]'
})
export class FavoriteDirective {
  // is used to bind a host element property to a directive property
  @HostBinding('class.is-favorite') isFavorite = true;

  @HostBinding('class.is-favorite-hovering') hovering = false;

  @HostListener('mouseenter') onMouseEnter() {
    this.hovering = true;
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.hovering = false;
  }

  @Input() set mwFavorite(value) {
    this.isFavorite = value;
  }
}
