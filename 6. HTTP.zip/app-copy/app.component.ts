import { Component } from '@angular/core';

/* Call decorator Component which takes in metadata object w/ known properties to
config class you decorate as an Angular component;
Provide two metadata properties at minimum: selector, template, or templateUrl */
@Component({
  selector: 'mw-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {}
