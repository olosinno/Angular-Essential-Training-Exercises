import { Component } from '@angular/core';

/* Call decorator Component which takes in metadata object w/ known properties to
config class you decorate as an Angular component;
Provide two metadata properties at minimum: selector, template, or templateUrl */
@Component({
  selector: 'mw-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'] // draws CSS from external file as an array of strings
})

export class AppComponent {
  firstMediaItem = {
    id: 1,
    name: 'Firebug',
    medium: 'Series',
    category: 'Science Fiction',
    year: 2010,
    watchedOn: 1-13-2016,
    isFavorite: false
  };
  onMediaItemDelete(mediaItem) {}
}
