import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { MediaItemComponent } from './media-item.component';

/* Decorator is a piece of code will be applied to class, or field or method coming before */
@NgModule({
/* Metadata properties used as an array
Imports bring in other Angular modules that module may need
Declarations used to make components, directives, and pipes available to your module
Bootstrap used for root module; tells Angular which components are Bootstrap entry point */
  imports: [
    BrowserModule // browser-based app has core directives and pipes to work with DOM
  ],
  declarations: [
    AppComponent,
    MediaItemComponent
  ],
  bootstrap: [
    AppComponent
  ]
})
/* Building module in its own file and need to import into another file?  Export keyword */
export class AppModule {}
