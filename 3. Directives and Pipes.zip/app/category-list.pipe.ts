import { Pipe, PipeTransform } from '@angular/core';

/* Pipe decorator accepts a metadata object with properties String name and pure */
@Pipe({
    name: 'categoryList',
    pure: true // pipe will intake data, then return data without any side effects
})

/* Import pipes into other files for usage */
export class CategoryListPipe implements PipeTransform {
    transform(mediaItems) {
        const categories = [];
        mediaItems.forEach(mediaItem => {
            if (categories.indexOf(mediaItem.category) <= -1)
            categories.push(mediaItem.category);
        });
        return categories.join(', ');
    }
}
